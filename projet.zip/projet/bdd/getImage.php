<?php
    $idProduit = $_GET['idProduit']; 
    //$idProduit = 1; 
	$bdd = new PDO('mysql:host=localhost;dbname=projet-site-revendeur;charset=UTF8', 'root', '') 
		or die('Erreur connexion à la base de données');
        $requete = "select image, image2, image3 from produit where pr_id = '$idProduit'";
        $resultat = $bdd->query($requete);
        //$img = $resultat->fetchAll(PDO::FETCH_ASSOC);
        $img = $resultat->fetch(PDO::FETCH_ASSOC);
        echo json_encode($img);
?>
