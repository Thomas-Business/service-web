<?php



function getLesCategories() {
    $lesCategories = null;
    $cnx = new PDO('mysql:host=localhost;dbname=projet-site-revendeur;charset=UTF8', 'root', '') 
    or die('Erreur connexion à la base de données');
    $sql = $cnx->prepare("select * from categorie");
    $sql->execute();
    $resultat =$sql->fetchAll(PDO::FETCH_ASSOC);
    return $resultat;
}


function getInfoProduit($idProduit){ 
    $infoProduit = null;
    $cnx = new PDO('mysql:host=localhost;dbname=projet-site-revendeur;charset=UTF8', 'root', '') 
    or die('Erreur connexion à la base de données');
    $sql = $cnx->prepare( "SELECT pr_libelle, pr_prix, image FROM produit WHERE pr_id = ?");
    $sql->bindValue(1,$idProduit);
    $sql->execute();
    $resultat =$sql->fetchAll(PDO::FETCH_ASSOC);
    return $resultat;
}



function getId($login){
    $idLogin = null;
    $bdd = new PDO('mysql:host=localhost;dbname=projet-site-revendeur;charset=UTF8', 'root', '') 
    or die('Erreur connexion à la base de données');

    $sql = $bdd->prepare("SELECT id FROM revendeur WHERE lg = ?");
    $sql->bindValue(1,$login);
    $sql->execute();
    $resultat =$sql->fetchAll(PDO::FETCH_ASSOC);
    return $resultat;
}


function ajoutProd($idProduit,$quantite, $idCommande){
    $bdd = new PDO('mysql:host=localhost;dbname=projet-site-revendeur;charset=UTF8', 'root', '') 
    or die('Erreur connexion à la base de données');
    $requete = $bdd->prepare("INSERT INTO `ligne_commande` (`id_ligne`,`pr_id`, `co_id`, `quantite`) VALUES (NULL,$idProduit, $idCommande, $quantite);");
    $requete->bindValue(1, $idProduit);
    $requete->bindValue(2, $idCommande);
    $requete->bindValue(3, $quantite);

    $requete->execute();
    
    // $resultat =$sql->fetchAll(PDO::FETCH_ASSOC);
    // return $resultat;
}



function ajoutCommande($login){
    $id = getId($login)[0]["id"];
    $bdd = new PDO('mysql:host=localhost;dbname=projet-site-revendeur;charset=UTF8', 'root', '') 
    or die('Erreur connexion à la base de données');
    $sql = $bdd->prepare("INSERT INTO `commande` (`co_id`, `co_date`, `id_revendeur`) VALUES (NULL,  CURRENT_DATE(), ?);");
    $sql->bindValue(1,$id);
    $sql->execute();
    $sql = $bdd->prepare("SELECT LAST_INSERT_ID()");
    $sql->execute();

    $resultat =$sql->fetch(PDO::FETCH_ASSOC);
    return $resultat;
}


?>





