<?php
  include 'nav2.html';
  include 'class/panier.php';
  include 'bdd/fonction.php';
  session_start();
  $login = $_SESSION["login"];
  $p = new panier();

  //valider la commande : 
  $lePanier = $p->getPanier();

  //ajout de la commande
  $idCommande = ajoutCommande($login)["LAST_INSERT_ID()"];



  foreach($lePanier as $idProduit => $produit){
    if($produit != 0){
        $infosProduit = getInfoProduit($idProduit);

        $pr_libelle = $infosProduit[0]["pr_libelle"];
        $image = $infosProduit[0]["image"];

        // var_dump($idProduit);
        // var_dump($produit);
        // var_dump($idCommande);


        //ajout du produit
        ajoutProd($idProduit,$produit, $idCommande);
    } 
  }

// Vider le panier :

if(!$p->vider()){
    header("location:index.php");
}else{
    echo "nous avons rencontrer un probleme veuillez redemarrer votre navigateur";
}

?>