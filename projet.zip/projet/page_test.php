<?php
function get_les_commandes() {
    $ret = null;
    $bdd = new PDO('mysql:host=localhost;dbname=projet-site-revendeur;charset=UTF8', 'root', '') 
    or die('Erreur connexion à la base de données');
    $requete = "select id_revendeur,co_date, co_id from commande";
    $resultat = $bdd->query($requete);
    $ret = $resultat->fetchAll();
    return $ret;
}
function get_prod_commander($commande_id) {
    $ret = null;
    $bdd = new PDO('mysql:host=localhost;dbname=projet-site-revendeur;charset=UTF8', 'root', '') 
    or die('Erreur connexion à la base de données');
    $requete = "select pr_id, quantite from ligne_commande WHERE co_id = '$commande_id'";
    $resultat = $bdd->query($requete);
    $ret = $resultat->fetchAll();
    return $ret;
}
//-----------------------------------------------------------------------------------------------------------

$lesCommandes = get_les_commandes();

// var_dump($lesCommandes);

// $commande_id = 17;
// var_dump(get_prod_commander($commande_id));

?>

<hr>


<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

        <title>test</title>
    </head>
    <body>


    <div class="container">

        <?php
        foreach($lesCommandes as $commande){
            // var_dump($commande);
            ?>
            <div class="shadow-lg p-3 mb-5 bg-body rounded">
                <p>date de commande : <?php echo $commande["co_date"]; ?></p>
                <p>id revendeur :  <?php echo $commande["id_revendeur"]; ?></p>
            
                <div class="row">
                    <?php
                    $commande_id = $commande["co_id"];
                    $lesProd_co =  get_prod_commander($commande_id);
                    // var_dump($lesProd_co);
                    foreach($lesProd_co as $prod_co){
                        // var_dump($prod_co);
                        ?>
                        <div class="col-sm-4">
                            <div class="shadow-lg p-3 mb-5 bg-body rounded">
                                <p>id du produit :  <?php echo $prod_co["pr_id"]; ?></p>
                                <p>quantite du produit :  <?php echo $prod_co["quantite"]; ?></p>
                            </div>
                        </div>
                </div>
                    <?php
                        
                    }
            ?>
            </div>
            <?php
        }
        ?>
    </div>























        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>

    </body>
</html>