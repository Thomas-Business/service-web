<?php
    include 'nav2.html';
    include 'class/panier.php';
    session_start();

    $p = new panier();

    if(!$p->vider()){
        header("location:lePanier.php");
            
    }else{
        echo "nous avons rencontrer un probleme lors du vidage du produit";
    }

    
?>