-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mar. 22 mars 2022 à 14:09
-- Version du serveur :  5.7.31
-- Version de PHP : 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `projet-site-revendeur`
--

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

DROP TABLE IF EXISTS `categorie`;
CREATE TABLE IF NOT EXISTS `categorie` (
  `ca_id` int(11) NOT NULL DEFAULT '0',
  `ca_libelle` varchar(40) NOT NULL DEFAULT '',
  `code_transport` int(11) NOT NULL,
  PRIMARY KEY (`ca_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`ca_id`, `ca_libelle`, `code_transport`) VALUES
(1, 'fauteuil', 1),
(2, 'canapé', 2),
(3, 'chaise', 3),
(4, 'armoire', 4);

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

DROP TABLE IF EXISTS `commande`;
CREATE TABLE IF NOT EXISTS `commande` (
  `co_id` int(11) NOT NULL AUTO_INCREMENT,
  `co_date` date NOT NULL,
  `id_revendeur` int(11) NOT NULL,
  PRIMARY KEY (`co_id`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `commande`
--

INSERT INTO `commande` (`co_id`, `co_date`, `id_revendeur`) VALUES
(71, '2022-03-22', 2),
(70, '2022-03-21', 1),
(69, '2022-03-21', 2);

-- --------------------------------------------------------

--
-- Structure de la table `ligne_commande`
--

DROP TABLE IF EXISTS `ligne_commande`;
CREATE TABLE IF NOT EXISTS `ligne_commande` (
  `id_ligne` int(11) NOT NULL AUTO_INCREMENT,
  `pr_id` int(11) NOT NULL,
  `co_id` int(11) NOT NULL,
  `quantite` int(11) NOT NULL,
  PRIMARY KEY (`id_ligne`),
  KEY `co_id` (`co_id`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `ligne_commande`
--

INSERT INTO `ligne_commande` (`id_ligne`, `pr_id`, `co_id`, `quantite`) VALUES
(46, 10, 71, 5),
(45, 2, 71, 2),
(44, 6, 70, 7),
(43, 9, 69, 3),
(42, 10, 69, 2);

-- --------------------------------------------------------

--
-- Structure de la table `prix_transport`
--

DROP TABLE IF EXISTS `prix_transport`;
CREATE TABLE IF NOT EXISTS `prix_transport` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_transport` int(11) NOT NULL,
  `prix` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `prix_transport`
--

INSERT INTO `prix_transport` (`id`, `code_transport`, `prix`) VALUES
(1, 1, 15.3),
(2, 2, 16.89),
(3, 3, 19.13),
(4, 4, 25.2);

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

DROP TABLE IF EXISTS `produit`;
CREATE TABLE IF NOT EXISTS `produit` (
  `pr_id` int(11) NOT NULL DEFAULT '0',
  `pr_libelle` varchar(40) NOT NULL DEFAULT '',
  `pr_prix` decimal(18,2) NOT NULL DEFAULT '0.00',
  `pr_categorie` int(11) NOT NULL DEFAULT '0',
  `image` text NOT NULL,
  `image2` text NOT NULL,
  `image3` text NOT NULL,
  PRIMARY KEY (`pr_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `produit`
--

INSERT INTO `produit` (`pr_id`, `pr_libelle`, `pr_prix`, `pr_categorie`, `image`, `image2`, `image3`) VALUES
(1, 'fauteuil confortable', '50.00', 1, 'images/pr1_1.jpg', 'images/pr1_2.jpg', 'images/pr1_3.jpg'),
(2, 'fauteuil de style', '100.00', 1, 'images/pr2_1.jpg', 'images/pr2_2.jpg', 'images/pr2_3.jpg'),
(3, 'fauteuil moderne', '75.00', 1, 'images/pr3_1.jpg', 'images/pr3_2.jpg', 'images/pr3_3.jpg'),
(4, 'fauteuil de style picard', '80.00', 1, 'images/pr4_1.jpg', 'images/pr4_2.jpg', 'images/pr4_3.jpg'),
(5, 'Canapé en cuir', '800.00', 2, 'images/pr5_1.jpg', 'images/pr5_2.jpg', 'images/pr5_3.jpg'),
(6, 'Petit canapé sympa', '450.00', 2, 'images/pr6_1.jpg', 'images/pr6_2.jpg', 'images/pr6_3.jpg'),
(7, 'Canapé 12 places', '2000.00', 2, 'images/pr7_1.jpg', 'images/pr7_2.jpg', 'images/pr7_3.jpg'),
(8, 'Chaise longue', '40.00', 3, 'images/pr8_1.jpg', 'images/pr8_2.jpg', 'images/pr8_3.jpg'),
(9, 'Chaise haute', '45.00', 3, 'images/pr9_1.jpg', 'images/pr9_2.jpg', 'images/pr9_3.jpg'),
(10, 'Petite chaise rouge', '25.00', 3, 'images/pr10_1.jpg', 'images/pr10_2.jpg', 'images/pr10_3.jpg'),
(11, 'Chaise bancale', '120.00', 3, 'images/pr11_1.jpg', 'images/pr11_2.jpg', 'images/pr11_3.jpg'),
(12, 'Chaise musicale', '250.00', 3, 'images/pr12_1.jpg', 'images/pr12_2.jpg', 'images/pr12_3.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `revendeur`
--

DROP TABLE IF EXISTS `revendeur`;
CREATE TABLE IF NOT EXISTS `revendeur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` text COLLATE utf8_bin NOT NULL,
  `lg` text COLLATE utf8_bin NOT NULL,
  `mdp` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `revendeur`
--

INSERT INTO `revendeur` (`id`, `nom`, `lg`, `mdp`) VALUES
(1, 'Thomas', 'shop-deco', '098f6bcd4621d373cade4e832627b4f6'),
(2, 'administrateur', 'admin', '21232f297a57a5a743894a0e4a801fc3');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
