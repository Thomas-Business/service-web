<?php
session_start();

if (session_destroy()) {
    header("Location:connexion.php");//renvoie vers connexion.php et non vers acceuil.php
} else {
    $_SESSION["connexion"] = false;//pas necessaire mais par mesure de securité
    echo '<p>Erreur : impossible de se déconnecter, veuillez fermer votre navigateur pour pouvoir vous déconnécter</p>';
}
?>