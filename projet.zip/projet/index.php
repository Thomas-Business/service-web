<?php
session_start();
//verification de connexion
$connexion = $_SESSION["connexion"];
$login = $_SESSION["login"];

//si connexion = false
if(!$connexion){
    header('Location:deconnexion.php');
}
include 'bdd/fonction.php';
include 'class/panier.php';
?>


<!doctype html>
<html lang="fr">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <title>Hello, world!</title>
  </head>
  <body>
  <?php
  if ($login == 'admin') {
    include 'nav.html';
  } else {
    include 'nav2.html';
  }
  ?>
<span class="space"></span>


<div class="container text-center fw-lighter">

  <h2> Recherche des Produits par Catégorie.</h2>
  <br>Liste des Categories : <br>
  <form action="ajoutPanier.php" method="post">
    <select id="listeCategorie" style="width: 180px;">
      <option>Selctionner</option>
    <?php
    $lesCategories = getLesCategories();
    foreach ($lesCategories as $categorie) {
      echo "<option value = '".$categorie['ca_id']."'>".$categorie['ca_libelle']."</option>";
    }
    ?>
    </select>
      <br><br>
      Liste des produits : 
      <br>
      <select name="produitSelectionner" id="listePdt" style="width: 180px;">
        <option>Selctionner</option>
      </select>
    <br><br>
    <div id="divPrix">Prix : </div>
    <span class="space"></span>
    <br>
    Saisir la quantite : 
    <input class="qt_selector" name="quantite" type="number" min="1" placeholder="0">
    <br><br>
    <h5>Photos : </h5>
    <div id="listePhoto">
    </div>
    <img style="width: 250px" id="img_produit">
    <br><br>
    <button type="submit" class="btn btn-danger">Ajouter au panier</button>
    <a type="button" href="lePanier.php" class="btn btn-primary">Voir le panier</a>

  </form>
    <br>
<br>
<br>
</div>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
  </body>
</html>



<script>
	let listeCategorie = document.getElementById("listeCategorie");
	listeCategorie.addEventListener("change", recupProduit);
	function recupProduit(){
		let idCategorie = listeCategorie.value;
		fetch("bdd/getProduitsParCategorie.php?idCateg="+ idCategorie)
		.then(response => response.json())
		.then(data => {
			let listePdt = document.getElementById("listePdt");
			listePdt.length = data.length;
			for (let i = 0 ; i < data.length ; i++){
				listePdt.options[i].text = data[i]["pr_libelle"];
				listePdt.options[i].value = data[i]["pr_id"];
			}
		})
		.catch(function (error) {
			console.log('Request failed', error);
		});
	}

	let listePdt = document.getElementById("listePdt");

	listePdt.addEventListener("change", recupInfo);
	function recupInfo(){
		let idProduit = listePdt.value;

        //recuperation du prix
        fetch("bdd/getPrix.php?idProduit="+ idProduit)
        .then(response => response.json())
        .then(data => {
        	let idPrix = document.getElementById("divPrix");
            // alert(data["pr_prix"]);
            idPrix.innerHTML = "Prix : " + data["pr_prix"];
        })
        //fin du recuperation de prix

        //recuperation d'image
        fetch("bdd/getImage.php?idProduit=" + idProduit)
        .then(response => response.json())
        .then(data => {

          // sert à vider la liste d'image
          document.getElementById("listePhoto").innerHTML="";
          let node = document.getElementById("listePhoto");
          while (node.hasChildNodes()){
            node.removeChild(node.firstChild);
          }

          // affiche les 3 images
          let img = new Image(200,200);
          img.src = data["image"];
          document.getElementById("listePhoto").appendChild(img);

          let img2 = new Image(200,200);
          img2.src = data["image2"];
          console.log(data)
          document.getElementById("listePhoto").appendChild(img2);

          let img3 = new Image(200,200);
          img3.src = data["image3"];
          document.getElementById("listePhoto").appendChild(img3);

        })
        //fin de recuperation d'image 
        .catch(function (error) {
        	console.log('Request failed', error);
        });
    }

</script>