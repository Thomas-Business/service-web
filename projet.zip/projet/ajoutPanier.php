<?php
  include 'nav2.html';
    include 'class/panier.php';
    session_start();
    echo "Valider";

    $p = new panier();

    if(isset($_POST["produitSelectionner"]) && isset($_POST["quantite"])){
        //   echo $_POST["produitSelectionner"];//c'est l'id du produit
        // echo $_POST["quantite"];//c'est la quatité
        
        if(!$p->ajouter($_POST["produitSelectionner"], intval($_POST["quantite"]))){
            header("location:index.php");
            
        }else{
            echo "nous avons rencontrer un probleme lors de l'ajout du produit";
        }
    }

    
?>