<?php
session_start();
//verification de connexion
$connexion = $_SESSION["connexion"];
//si connexion = false
if(!$connexion){
    header('Location:deconnexion.php');
}
include 'bdd/fonction.php';
include 'class/panier.php';

$p = new panier();//classe panier


$lePanier = $p->getPanier();
// var_dump($lePanier);

//Total du prix
$login = $_SESSION["login"];
// echo getId($login)[0]["id"];
?>
<!doctype html>
<html lang="fr">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
        <link rel="stylesheet" href="css/style.css">
        <title>Hello, world!</title>
    </head>
    <body>
    <?php
  if ($login == 'admin') {
    include 'nav.html';
  } else {
    include 'nav2.html';
  }
  ?>
    <br>
    <h1 class="text-center">Votre Panier</h1>
    <hr>
    <br><br><br>


    <div class="container">
        <div class="shadow-sm p-3 mb-5 bg-body rounded">
            <table class="table">
            <thead>
                <tr>
                    <th scope="col">Image</th>
                    <th scope="col">Description</th>
                    <th scope="col">Quantité</th>
                    <th scope="col">Prix</th>
                </tr>
            </thead>
            <tbody>

                <?php
                $prixTotal = 0;
                foreach($lePanier as $idProduit => $produit){
                    if($produit != 0){
                        $infosProduit = getInfoProduit($idProduit);
                        // var_dump($infosProduit);
                        
                        $prix = $infosProduit[0]["pr_prix"];
                        $pr_libelle = $infosProduit[0]["pr_libelle"];
                        $image = $infosProduit[0]["image"];

                        $prixTotal = (intval($prix)* $produit) + $prixTotal;//Total des prix

                        ?>
                        <tr>
                            <th><img src="<?php echo $image; ?>" style="width:100px"></th>
                            <th style="text-transform:uppercase;"><?php echo $pr_libelle; ?></th>
                            <th><?php echo $produit; ?></th>
                            <th><?php echo $prix; ?></th>
                        </tr>
                        <?php
                    }
                }
                ?>
            </tbody>
            </table>
        </div>
        <hr class="hr_panier">


        <div class="text-end">
            <div class="shadow-sm p-3 mb-5 bg-body rounded">
                <h5>TOTAL : <?php echo $prixTotal; ?>€ </h5>
            </div>
            <a type="button" href="vider_le_panier.php" class="btn btn-danger">Vider le panier</a>
            <a type="button" href="validerCommande.php" class="btn btn-primary">Valider la commande</a>
        </div>
    </div>



<br><br><br><br>







    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>

  </body>
</html>