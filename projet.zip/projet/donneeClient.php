<?php 


session_start(); 
if (isset($_SESSION['connexion'])) {

	$login = $_SESSION["login"];
	if ($login != 'admin') {
		header("Location: index.php");
	}
    $bdd = new PDO('mysql:host=localhost;dbname=projet-site-revendeur;charset=UTF8', 'root', '') 
    or die('Erreur connexion à la base de données');

	$reqAllCmd = $bdd->query("SELECT * FROM commande");
	$reqAllProduit = $bdd->query("SELECT * FROM `ligne_commande`");

?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
	<meta charset="utf-8">
	<title></title>
</head>
<header>
<?php
  if ($login == 'admin') {
    include 'nav.html';
  } else {
    include 'nav2.html';
  }
  ?>
</header><br><br><br>
<body>
	<div class="container"><br>
		<h1 class="title">Données clients</h1><br><br>
		<table class="table">
			<thead>
				<tr class="table-primary">
					<td>
						ID commande
					</td>
					<td>
						ID revendeur
					</td>
					<!-- <td>
						Numéro commande
					</td>
					<td>
						Commande
					</td>
					<td>
						Prix Total
					</td> -->
					<td>
						Date de la commande
					</td>

				</tr>
			</thead>
			<tbody>
				<?php 

				 while ($infoClient = $reqAllCmd->fetch()) {
				  
				?>
				<tr class="table-warning">
					<td>
						<?= $infoClient["co_id"] ?>
					</td>
					<td>
						<?= $infoClient["id_revendeur"] ?>
					</td>
					<!--<td>
						<?= $infoClient["numero_commande"] ?>
					</td>
					<td>
						<?= $infoClient["commande"] ?>
					</td>
					<td>
						<?= $infoClient["prix_total"] ?> €
					</td> -->
					<td>
						<?= $infoClient["co_date"] ?>
					</td>
				</tr>
				<?php } ?>
			</tbody>
			
		</table>
	</div>

	<div class="container"><br>
		<h1 class="title">Contenu des commandes :</h1><br><br>
		<table class="table">
			<thead>
				<tr class="table-primary">
					<td>
						ID commande
					</td>
					<td>
						ID produit
					</td>
					<!-- <td>
						Numéro commande
					</td>
					<td>
						Commande
					</td>
					<td>
						Prix Total
					</td> -->
					<td>
						quantité
					</td>

				</tr>
			</thead>
			<tbody>
				<?php 

				 while ($infoClient = $reqAllProduit->fetch()) {
				  
				?>
				<tr class="table-warning">
					<td>
						<?= $infoClient["co_id"] ?>
					</td>
					<td>
						<?= $infoClient["pr_id"] ?>
					</td>
					<td>
						<?= $infoClient["quantite"] ?>
					</td>
				</tr>
				<?php } ?>
			</tbody>
			
		</table>
	</div>


</body>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>

</html>

<?php    
}
else{
	header("Location: connexion.php");
}

?>