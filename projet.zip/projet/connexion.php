<?php
include 'bdd/fonction.php';
//connexion a la base de données
// dsn = Data Source Name = driver MYSQL
$dsn='mysql:dbname=projet-site-revendeur;host=localhost';
//login
$login='root';
// Mot de passe
$motDePasse='';
// Connexion au serveur MySQL
try{
    $cnx = new PDO($dsn, $login, $motDePasse,
            array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
}
catch (PDOException $e){
	die('Erreur : ' . $e->getMessage());
}


?>

<!doctype html>
<html lang="fr">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>

  <div style="margin-top:30vh"></div>


    <div class="container shadow-lg p-3 mb-5 bg-body rounded">
      <h4 class="text-center">Identification</h4>
        <form action="" method="POST">
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Identifiant</label>
              <input name="login" type="text" class="form-control">
            </div>
            <div class="mb-3">
              <label for="exampleInputPassword1" class="form-label">Mots de passe</label>
              <input name="mdp" type="password" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Connexion</button>
          </form>
    </div>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>

  </body>
</html>


<?php

if(isset($_POST["login"]) && isset($_POST["mdp"])){
    //requette mySQL :
    $rqt = $cnx->prepare("select nom from revendeur where lg = ? and mdp = MD5(?)");
    $rqt-> bindValue(1,$_POST["login"]);
    $rqt-> bindValue(2,$_POST["mdp"]);
    $rqt->execute();

    if(count($rqt->fetchAll()) == 0)
    {
        ?>
        <h4 class="text-center">Identifiants incorrects</h4>
        <?php
    }
    else
    {
        session_start();
        $_SESSION["login"] = $_POST["login"];
        $_SESSION["connexion"] = true;
        header('Location:index.php');
    }
}
?>